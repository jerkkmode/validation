
<!DOCTYPE HTML>  
<html>
<head>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<title>Validation Form</title>
<style>
*{
  background-color:white;
}
.error {
  color: #FF0000;
}
#input{
  margin: 50px 0px 0px 250px;
  padding: 20px;
  height: 500px;
width: 450px;
border-style: outset;
}
.form-group {
  background-color: white;
  display: inline-block; 
}

#title {
  color:white;
  background-color: #ff0000;
  height: 10px;
  padding-top: 10px;
  text-align: center;
}
#output {
  margin: 50px;
  padding: 10px;
  height: 500px;
width: 450px;
border-style: outset;
text-align: center;
}
.row {
  clear: both;
}
.column{
  float: left;
  width: 50%;
  padding: 10px;
  height: 300px;
}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$nameErr = $emailErr = $usernameErr = $passwordErr = $genderErr = "";
$name = $email = $username = $password = $comment = $gender = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	//Name
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }
  
  //Email
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  //Username  
  if (empty($_POST["username"])) {
    $usernameErr = "Username is required";
  } else {
    $username = test_input($_POST["username"]);
  }

  //Password
  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = test_input($_POST["password"]);
  }

  //Comment
  if (empty($_POST["comment"])) {
    $comment = "";
  } else {
    $comment = test_input($_POST["comment"]);
  }

  //Gender
  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

  <h2 id="title" class="jumbotron jumbotron-fluid">PHP Form Validation Example</h2>
  <div class="row">
    <div id="input" class="column">
      <form method="post" action="<?php echo htmlentities($_SERVER["PHP_SELF"]);?>" autocomplete="on">
        <div class="form-group">  
          Name: <input type="text" name="name" required="">
          
        </div>
        <div class="form-group"> 
          E-mail: <input type="text" name="email" required="" >
          
        </div>
        <div class="form-group">  
          Username: <input type="text" name="username" required="">
          
        </div>
        <div class="form-group"> 
          Password: <input type="password" name="password" required="">
          
        </div>
        <div class="form-group"> 
          Comment: <textarea name="comment" rows="5" cols="40" required=""></textarea>
        </div>
        <div class="form-group">
          Gender:
          <input type="radio" name="gender" value="female" required="">Female
          <input type="radio" name="gender" value="male" required="">Male
        </div>
          <br><br>
          <input type="submit" name="submit" class="btn btn-danger"></input>  
      </form>
    </div>
      <div id="output" class="column">
        <?php
          echo "<h2>Your Input:</h2>";
          echo "<br>";
          

          echo "<h3>Username: $username </h3>";       
          echo "<h3>Password: $password </h3>";
          echo "<h5>Name:  $name </h5>";
          echo "<h5>Email: $email </h5>";   
          echo "<h5>Comment: $email </h5>";    
          echo "<h5>Gender: $gender </h5>";
        ?>  
      </div>
  </div>
</body>
</html>