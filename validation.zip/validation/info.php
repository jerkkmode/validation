<?php 
	session_start();
	$name = $_SESSION['$name'];
	$email = $_SESSION['$email'];
	$username = $_SESSION['$username'];
	$password = $_SESSION['$password'];
	$comment = $_SESSION['$comment'];
	$gender = $_SESSION['$gender'];
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<title>Validation Form</title>
</head>
<body>
<div class="container">
<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $username;
echo "<br>";
echo $password;
echo "<br>";
echo $comment;
echo "<br>";
echo $gender;
?>	
<a href="index.php"><button class="btn btn-dark">Back to Home</button></a>
</div>
</body>
</html>